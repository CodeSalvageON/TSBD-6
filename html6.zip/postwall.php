<?php
  
  
    $myfile = fopen("source1.html", "a+");
    $txt = "<img src='wall.jpeg' />";
    fwrite($myfile, $txt);
    fclose($myfile);
    flush();
    
    
?>
<center><p><h1><a href="https://SpielChat.codesalvageon.repl.co">POST</a></h1></p></center>
<center>
<script>
location = "https://html6.codesalvageon.repl.co/source1.html"
</script>
</center>