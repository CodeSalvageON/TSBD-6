<html>
  <head>
    <title>Town and Structure Building Demo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
  </head>
  <body>
  <script>
  </script>
  <style id="sky">
  body{
    background-image:url('clouds.jpg');
    background-size:cover;
  }
  </style>
  <center id="wow"></center>
  <CENTER><tt><h1>One Neighborhood</h1></tt></CENTER>
  <a href="rules.html"><center><tt><h3><i>Repl.it's Free Speech Platform</i></h3></tt></center></a>
  <center><iframe src="https://chatwoo.codesalvageon.repl.run" width="800" height="50"></iframe></center>
  <center><iframe src="news.html" width="800" height="50"></iframe></center>
  
  <center><iframe src="source1.html"width="1000" height="700"></iframe></center>
  <p>
  <form action="">
  </form>
  </p>
  
  </body>
  
</html>