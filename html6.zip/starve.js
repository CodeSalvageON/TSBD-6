var starve = 20
var health = 20

setInterval('st()', 10000)

function st() {
  starve = starve - 1
  document.getElementById('hunger').innerHTML = 'Hunger: '+starve;
  if (starve < 1) {
    health = health - 1
    document.getElementById('health').innerHTML = 'Health: '+health;
    if (health<1) {
      alert('You starved to death.')
      window.close()
    }
  }
}
caf() {
  starve = starve + 10
  health = health + 10
  getElementById('hunger').innerHTML = 'Hunger: '+starve;
  getElementById('health').innerHTML = 'Health: '+health;
}