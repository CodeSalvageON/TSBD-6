<?php
  
  
    $myfile = fopen("news.html", "w");
    $txt = "</center>
News: <a href=''><button>Refresh</button></a><tt>Gunshots heard at Roxstrait Middle School!</tt>";
    fwrite($myfile, $txt);
    fclose($myfile);
    flush();
    
    
?>
<center><p><h1><a href="https://SpielChat.codesalvageon.repl.co">POST</a></h1></p></center>
<center>
<script>
location = "https://html6.codesalvageon.repl.co/source1.html"
</script>