<?php
  
  
    $myfile = fopen("freespeech3.html", "a+");
    $txt = "<img src='".$_POST['pass']."' />";
    fwrite($myfile, $txt);
    fclose($myfile);
    flush();
    
    
?>

<center><p><h1><a href="https://SpielChat.codesalvageon.repl.co">POST</a></h1></p></center>
<center>
<script>
location = "https://html6.codesalvageon.repl.co/freespeech3.html"
</script>
</center>