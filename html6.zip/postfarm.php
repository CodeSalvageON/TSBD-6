<?php
  
  
    $myfile = fopen("source1.html", "a+");
    $txt = "<a href='farm.html'><img src='farm2.png' width='100' height='80'/></a>";
    fwrite($myfile, $txt);
    fclose($myfile);
    flush();
    
    
?>
<center><p><h1><a href="https://SpielChat.codesalvageon.repl.co">POST</a></h1></p></center>
<center>
<script>
location = "https://html6.codesalvageon.repl.co/source1.html"
</script>
</center>