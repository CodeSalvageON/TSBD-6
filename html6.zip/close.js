function close() {
  window.close()
}